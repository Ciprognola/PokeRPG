PokeRPG pose templates
======================

Grey-mannequin references that show an image AI the 24 walk poses of a character.
Full instructions: docs/SPRITE_REFERENCE.md in the repository, sections 4 and 5.

grid-template.png     One image, 4:3 (2400 x 1800), 6 columns x 4 rows, no lines or labels.
                      Rows: toward you, walking left, walking right, walking away.
                      Columns: contact, down, passing, contact, down, passing.
                      Use it as the composition reference for a one-image sprite sheet.

single/               The same 24 poses as separate images, named walk_down_00.png ...
                      walk_up_05.png. Use them for the frame-by-frame fallback and keep
                      the file names: the Slicer orders frames by them.

The background is flat magenta (#FF00FF). Keep magenta and hot pink out of your character.
